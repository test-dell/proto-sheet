import { Template, DASheet, Vendor } from '../types/da-types';

export const defaultTemplates: Template[] = [
  {
    id: 'template-1',
    name: 'License Agreement Template',
    type: 'License',
    description: 'Standard template for software licensing decisions',
    isDeployed: true,
    categories: [
      {
        id: 'quality',
        name: 'Quality',
        parameters: [
          {
            id: 'q1',
            name: 'Development needs',
            weightage: 10,
            comment: 'Development needs to be done from scratch as an intermediate. 1: Not Capable - 2)'
          },
          {
            id: 'q2',
            name: 'Code-Low-Code Platform',
            weightage: 10,
            comment: 'Yes/No/Partially - No code/low-code solution with interactive dashboard'
          },
          {
            id: 'q3',
            name: 'Template implementation',
            weightage: 5,
            comment: 'Yes, the templates are dynamically parameterized'
          },
          {
            id: 'q4',
            name: 'Technical support',
            weightage: 5,
            comment: 'Documentation or partner support'
          }
        ]
      },
      {
        id: 'cost',
        name: 'Cost',
        parameters: [
          {
            id: 'c1',
            name: 'Licensing Cost',
            weightage: 10,
            comment: 'Upfront + AMC (License = x AM and One Time Cost = y, Cost with budgeting module z)'
          },
          {
            id: 'c2',
            name: 'One Time Cost',
            weightage: 5,
            comment: 'Implementation and setup costs'
          }
        ]
      },
      {
        id: 'delivery',
        name: 'Delivery',
        parameters: [
          {
            id: 'd1',
            name: 'Integration capability',
            weightage: 10,
            comment: 'System scope is only part of end-to-end process - different systems - need to integrate with SAC'
          },
          {
            id: 'd2',
            name: 'Implementation timeline',
            weightage: 5,
            comment: 'Go-live within 6 weeks and 3 months iterations'
          }
        ]
      },
      {
        id: 'management',
        name: 'Management',
        parameters: [
          {
            id: 'm1',
            name: 'Licensing Model',
            weightage: 5,
            comment: 'User based license model'
          },
          {
            id: 'm2',
            name: 'Network Partners',
            weightage: 10,
            comment: 'Confluence plus Network (Multiple stakeholders across entities in market)'
          }
        ]
      },
      {
        id: 'safety',
        name: 'Safety',
        parameters: [
          {
            id: 's1',
            name: 'Security Certification',
            weightage: 10,
            comment: 'Has Magic Quadrant for Financial Planning (Not in Magic Quadrant for Financial Planning)'
          },
          {
            id: 's2',
            name: 'Data compliance',
            weightage: 5,
            comment: 'Satisfies Security Certification - India Data Centre Level 3 SOC 2 Type 1 & 2, ISO/IEC 27001'
          }
        ]
      }
    ],
    customFields: [],
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-01-15')
  },
  {
    id: 'template-2',
    name: 'Custom Development Template',
    type: 'Custom Development',
    description: 'Template for custom software development vendor evaluation',
    isDeployed: true,
    categories: [
      {
        id: 'quality',
        name: 'Quality',
        parameters: [
          {
            id: 'q1',
            name: 'Technical Expertise',
            weightage: 15,
            comment: 'Development team skill level and certifications'
          },
          {
            id: 'q2',
            name: 'Code Quality Standards',
            weightage: 10,
            comment: 'Adherence to coding standards and best practices'
          },
          {
            id: 'q3',
            name: 'Testing Capabilities',
            weightage: 10,
            comment: 'Automated testing and QA processes'
          }
        ]
      },
      {
        id: 'cost',
        name: 'Cost',
        parameters: [
          {
            id: 'c1',
            name: 'Development Cost',
            weightage: 15,
            comment: 'Total development and customization costs'
          },
          {
            id: 'c2',
            name: 'Maintenance Cost',
            weightage: 5,
            comment: 'Annual maintenance and support fees'
          }
        ]
      },
      {
        id: 'delivery',
        name: 'Delivery',
        parameters: [
          {
            id: 'd1',
            name: 'Project Timeline',
            weightage: 10,
            comment: 'Ability to meet project deadlines'
          },
          {
            id: 'd2',
            name: 'Agile Methodology',
            weightage: 5,
            comment: 'Use of agile development practices'
          }
        ]
      },
      {
        id: 'management',
        name: 'Management',
        parameters: [
          {
            id: 'm1',
            name: 'Project Management',
            weightage: 10,
            comment: 'Project management capabilities and tools'
          },
          {
            id: 'm2',
            name: 'Communication',
            weightage: 5,
            comment: 'Regular updates and stakeholder communication'
          }
        ]
      },
      {
        id: 'safety',
        name: 'Safety',
        parameters: [
          {
            id: 's1',
            name: 'Security Standards',
            weightage: 10,
            comment: 'Compliance with security standards (ISO 27001, SOC 2)'
          },
          {
            id: 's2',
            name: 'Data Protection',
            weightage: 5,
            comment: 'Data encryption and protection measures'
          }
        ]
      }
    ],
    customFields: [],
    createdAt: new Date('2024-01-20'),
    updatedAt: new Date('2024-01-20')
  },
  {
    id: 'template-3',
    name: 'SaaS Solution Template',
    type: 'SaaS',
    description: 'Template for SaaS product evaluation',
    isDeployed: true,
    categories: [
      {
        id: 'quality',
        name: 'Quality',
        parameters: [
          {
            id: 'q1',
            name: 'Feature Completeness',
            weightage: 15,
            comment: 'Coverage of required features and functionality'
          },
          {
            id: 'q2',
            name: 'User Experience',
            weightage: 10,
            comment: 'Ease of use and interface design'
          },
          {
            id: 'q3',
            name: 'Customization Options',
            weightage: 5,
            comment: 'Ability to customize and configure'
          }
        ]
      },
      {
        id: 'cost',
        name: 'Cost',
        parameters: [
          {
            id: 'c1',
            name: 'Subscription Cost',
            weightage: 15,
            comment: 'Monthly/annual subscription fees per user'
          },
          {
            id: 'c2',
            name: 'Implementation Cost',
            weightage: 5,
            comment: 'Setup and onboarding costs'
          }
        ]
      },
      {
        id: 'delivery',
        name: 'Delivery',
        parameters: [
          {
            id: 'd1',
            name: 'Deployment Speed',
            weightage: 10,
            comment: 'Time to deploy and go live'
          },
          {
            id: 'd2',
            name: 'Integration APIs',
            weightage: 10,
            comment: 'API availability and ease of integration'
          }
        ]
      },
      {
        id: 'management',
        name: 'Management',
        parameters: [
          {
            id: 'm1',
            name: 'Vendor Reputation',
            weightage: 10,
            comment: 'Market presence and customer reviews'
          },
          {
            id: 'm2',
            name: 'Support Quality',
            weightage: 5,
            comment: '24/7 support and SLA guarantees'
          }
        ]
      },
      {
        id: 'safety',
        name: 'Safety',
        parameters: [
          {
            id: 's1',
            name: 'Data Security',
            weightage: 10,
            comment: 'Encryption, backup, and disaster recovery'
          },
          {
            id: 's2',
            name: 'Compliance',
            weightage: 5,
            comment: 'GDPR, HIPAA, SOC 2 compliance'
          }
        ]
      }
    ],
    customFields: [],
    createdAt: new Date('2024-02-01'),
    updatedAt: new Date('2024-02-01')
  }
];

// Helper function to create empty vendor scores based on template
const createEmptyVendorScores = (template: Template) => {
  const scores: any = {};
  
  template.categories.forEach(category => {
    scores[category.id] = {
      evaluations: category.parameters.map(param => ({
        parameterId: param.id,
        evalScore: 0,
        result: 0,
        vendorComment: ''
      })),
      subTotal: 0
    };
  });
  
  return scores;
};

export const mockDASheets: DASheet[] = [
  {
    id: 'da-1',
    name: 'ERP System Evaluation Q1 2024',
    type: 'License',
    status: 'Draft',
    templateId: 'template-1',
    vendors: [
      {
        id: 'vendor-1',
        name: 'ServiceNow',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 8, result: 80, vendorComment: 'Development needs to be done from scratch as an intermediate. 1: Not Capable - 3)' },
              { parameterId: 'q2', evalScore: 10, result: 100, vendorComment: 'Yes, the templates can be created as per requirement' },
              { parameterId: 'q3', evalScore: 10, result: 50, vendorComment: 'Yes/No/Partially - No code/low-code solution with interactive dashboard' },
              { parameterId: 'q4', evalScore: 10, result: 50, vendorComment: 'Yes - No customization NW Level - 1 : No customization SOC 2 Type 1 or 2)' }
            ],
            subTotal: 280
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 8, result: 80, vendorComment: 'License = 5 AM and One Time Cost = Y' },
              { parameterId: 'c2', evalScore: 10, result: 50, vendorComment: 'Zone Time Cost' }
            ],
            subTotal: 130
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 2, result: 20, vendorComment: 'System scope is only part of end-to-end process - different systems - need to integrate with SAC' },
              { parameterId: 'd2', evalScore: 10, result: 50, vendorComment: '12 Weeks and 3 months iterations' }
            ],
            subTotal: 70
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 8, result: 40, vendorComment: 'User based license model' },
              { parameterId: 'm2', evalScore: 10, result: 100, vendorComment: 'Limited Implementation Partners in market' }
            ],
            subTotal: 140
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 2, result: 20, vendorComment: 'Not in Magic Quadrant for Financial Planning' },
              { parameterId: 's2', evalScore: 10, result: 50, vendorComment: 'UK Data Centre Level 3 SOC 2 Type 1 & 2, ISO/IEC 27001' }
            ],
            subTotal: 70
          }
        },
        overallScore: 690,
        notes: 'Strong integration capabilities'
      },
      {
        id: 'vendor-2',
        name: 'PaaS/Comp',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 9, result: 90, vendorComment: 'Development needs to be done from scratch as an intermediate' },
              { parameterId: 'q2', evalScore: 10, result: 100, vendorComment: 'Development needs to be done from scratch as an Intermediate. 1: Not Capable - 2)' },
              { parameterId: 'q3', evalScore: 10, result: 50, vendorComment: 'Yes/No/Partially - No code/low-code Platform creation capabilities are less as they are replacement' },
              { parameterId: 'q4', evalScore: 10, result: 50, vendorComment: 'No templates implementation partners are available in the market' }
            ],
            subTotal: 290
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 9, result: 90, vendorComment: 'License = 6 AM' },
              { parameterId: 'c2', evalScore: 10, result: 50, vendorComment: '5 TM Cost' }
            ],
            subTotal: 140
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 2, result: 20, vendorComment: 'Business scope is early part of end-to-end process - different systems' },
              { parameterId: 'd2', evalScore: 2, result: 10, vendorComment: '24 Weeks and 6 months iterations' }
            ],
            subTotal: 30
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 10, result: 50, vendorComment: 'Limited license model' },
              { parameterId: 'm2', evalScore: 10, result: 100, vendorComment: 'Not yet done On-Premise Apex environment' }
            ],
            subTotal: 150
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 2, result: 20, vendorComment: 'Not in Magic Quadrant for Financial Planning' },
              { parameterId: 's2', evalScore: 10, result: 50, vendorComment: 'Leader in magic quadrant for Financial Planning. Yes - On-Premise Apex environment' }
            ],
            subTotal: 70
          }
        },
        overallScore: 680,
        notes: 'Cost-effective solution'
      }
    ],
    notes: 'Initial evaluation for Q1 procurement',
    version: 1,
    createdAt: new Date('2024-03-01'),
    updatedAt: new Date('2024-03-15'),
    createdBy: 'Sarah Johnson',
    sharedWith: [
      {
        email: 'john.manager@company.com',
        accessLevel: 'edit',
        sharedAt: new Date('2024-03-02')
      },
      {
        email: 'mary.analyst@company.com',
        accessLevel: 'view',
        sharedAt: new Date('2024-03-05')
      }
    ]
  },
  {
    id: 'da-2',
    name: 'Cloud Migration Platform Review',
    type: 'SaaS',
    status: 'Draft',
    templateId: 'template-3',
    vendors: [],
    notes: '',
    version: 1,
    createdAt: new Date('2024-03-10'),
    updatedAt: new Date('2024-03-10'),
    createdBy: 'Michael Chen',
    sharedWith: []
  },
  {
    id: 'da-3',
    name: 'Project Management Tool Selection 2024',
    type: 'SaaS',
    status: 'Approved',
    templateId: 'template-3',
    vendors: [
      {
        id: 'vendor-pm-1',
        name: 'Asana',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 9, result: 135, vendorComment: 'Comprehensive project management features with excellent task tracking and workflow automation' },
              { parameterId: 'q2', evalScore: 9, result: 90, vendorComment: 'Intuitive interface with modern design and easy navigation' },
              { parameterId: 'q3', evalScore: 7, result: 35, vendorComment: 'Good customization options for workflows and templates' }
            ],
            subTotal: 260
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 7, result: 105, vendorComment: '$10.99 per user/month for Business tier' },
              { parameterId: 'c2', evalScore: 8, result: 40, vendorComment: 'Low implementation cost, self-service onboarding available' }
            ],
            subTotal: 145
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 9, result: 90, vendorComment: 'Immediate deployment, users can start within hours' },
              { parameterId: 'd2', evalScore: 8, result: 80, vendorComment: 'Excellent API documentation with 100+ integrations available' }
            ],
            subTotal: 170
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 9, result: 90, vendorComment: 'Strong market presence with 100,000+ customers globally' },
              { parameterId: 'm2', evalScore: 8, result: 40, vendorComment: 'Premium support with 24/7 availability and 2-hour response time SLA' }
            ],
            subTotal: 130
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 9, result: 90, vendorComment: 'SOC 2 Type II certified with AES-256 encryption' },
              { parameterId: 's2', evalScore: 9, result: 45, vendorComment: 'GDPR compliant with data residency options' }
            ],
            subTotal: 135
          }
        },
        overallScore: 840,
        notes: 'Top performer with excellent features and user experience'
      },
      {
        id: 'vendor-pm-2',
        name: 'Monday.com',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 8, result: 120, vendorComment: 'Visual project management with good feature coverage' },
              { parameterId: 'q2', evalScore: 10, result: 100, vendorComment: 'Outstanding visual interface with color-coded boards' },
              { parameterId: 'q3', evalScore: 9, result: 45, vendorComment: 'Highly customizable with templates and automation builders' }
            ],
            subTotal: 265
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 6, result: 90, vendorComment: '$12 per user/month, higher pricing than competitors' },
              { parameterId: 'c2', evalScore: 7, result: 35, vendorComment: 'Implementation support available at additional cost' }
            ],
            subTotal: 125
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 10, result: 100, vendorComment: 'Instant deployment with quick team onboarding' },
              { parameterId: 'd2', evalScore: 9, result: 90, vendorComment: 'Strong API with 200+ native integrations' }
            ],
            subTotal: 190
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 8, result: 80, vendorComment: 'Growing market presence with 150,000+ customers' },
              { parameterId: 'm2', evalScore: 7, result: 35, vendorComment: 'Good support with business hours coverage' }
            ],
            subTotal: 115
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 8, result: 80, vendorComment: 'SOC 2 Type II and ISO 27001 certified' },
              { parameterId: 's2', evalScore: 8, result: 40, vendorComment: 'GDPR and HIPAA compliant' }
            ],
            subTotal: 120
          }
        },
        overallScore: 815,
        notes: 'Strong visual interface, slightly higher cost'
      },
      {
        id: 'vendor-pm-3',
        name: 'Jira',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 8, result: 120, vendorComment: 'Comprehensive agile and scrum features, developer-focused' },
              { parameterId: 'q2', evalScore: 6, result: 60, vendorComment: 'Learning curve for non-technical users' },
              { parameterId: 'q3', evalScore: 10, result: 50, vendorComment: 'Extensive customization with workflows and custom fields' }
            ],
            subTotal: 230
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 8, result: 120, vendorComment: '$7.75 per user/month for Standard tier, competitive pricing' },
              { parameterId: 'c2', evalScore: 6, result: 30, vendorComment: 'Setup requires technical expertise' }
            ],
            subTotal: 150
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 8, result: 80, vendorComment: 'Cloud deployment available, setup takes 1-2 days' },
              { parameterId: 'd2', evalScore: 10, result: 100, vendorComment: 'Excellent API and extensive marketplace integrations' }
            ],
            subTotal: 180
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 10, result: 100, vendorComment: 'Market leader by Atlassian with 200,000+ customers' },
              { parameterId: 'm2', evalScore: 7, result: 35, vendorComment: 'Premium support available with SLA guarantees' }
            ],
            subTotal: 135
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 9, result: 90, vendorComment: 'SOC 2, ISO 27001, and PCI DSS certified' },
              { parameterId: 's2', evalScore: 9, result: 45, vendorComment: 'GDPR compliant with EU data residency' }
            ],
            subTotal: 135
          }
        },
        overallScore: 830,
        notes: 'Best for technical teams with strong agile focus'
      }
    ],
    notes: 'Final approved version for Q1 2024 project management tool selection',
    version: 2,
    createdAt: new Date('2024-01-10'),
    updatedAt: new Date('2024-02-15'),
    createdBy: 'Emily Rodriguez',
    approvedBy: 'Sarah Johnson',
    approvedAt: new Date('2024-02-20'),
    sharedWith: []
  },
  {
    id: 'da-4',
    name: 'CRM System Vendor Evaluation',
    type: 'License',
    status: 'Approved',
    templateId: 'template-1',
    vendors: [
      {
        id: 'vendor-crm-1',
        name: 'Salesforce',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 10, result: 100, vendorComment: 'Industry-leading CRM with extensive customization' },
              { parameterId: 'q2', evalScore: 9, result: 90, vendorComment: 'Low-code platform with Lightning App Builder' },
              { parameterId: 'q3', evalScore: 10, result: 50, vendorComment: 'Comprehensive template marketplace available' },
              { parameterId: 'q4', evalScore: 9, result: 45, vendorComment: 'Extensive documentation and Trailhead learning platform' }
            ],
            subTotal: 285
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 6, result: 60, vendorComment: 'Enterprise edition $150/user/month, premium pricing' },
              { parameterId: 'c2', evalScore: 5, result: 25, vendorComment: 'Significant implementation and consulting costs' }
            ],
            subTotal: 85
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 9, result: 90, vendorComment: 'Native integration with 1000+ applications' },
              { parameterId: 'd2', evalScore: 7, result: 35, vendorComment: 'Implementation timeline 3-6 months depending on complexity' }
            ],
            subTotal: 125
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 9, result: 45, vendorComment: 'Flexible user-based licensing model' },
              { parameterId: 'm2', evalScore: 10, result: 100, vendorComment: 'Extensive partner network with certified consultants globally' }
            ],
            subTotal: 145
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 10, result: 100, vendorComment: 'Leader in Gartner Magic Quadrant for CRM' },
              { parameterId: 's2', evalScore: 10, result: 50, vendorComment: 'SOC 2 Type II, ISO 27001, PCI DSS certified with global data centers' }
            ],
            subTotal: 150
          }
        },
        overallScore: 790,
        notes: 'Premium solution with highest capabilities but significant cost'
      },
      {
        id: 'vendor-crm-2',
        name: 'HubSpot',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 8, result: 80, vendorComment: 'User-friendly CRM with marketing automation' },
              { parameterId: 'q2', evalScore: 10, result: 100, vendorComment: 'Fully no-code platform with drag-and-drop interface' },
              { parameterId: 'q3', evalScore: 8, result: 40, vendorComment: 'Good template library for emails and workflows' },
              { parameterId: 'q4', evalScore: 9, result: 45, vendorComment: 'Excellent documentation and HubSpot Academy resources' }
            ],
            subTotal: 265
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 8, result: 80, vendorComment: 'Professional tier $90/user/month, competitive pricing' },
              { parameterId: 'c2', evalScore: 9, result: 45, vendorComment: 'Lower implementation costs, self-service options available' }
            ],
            subTotal: 125
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 8, result: 80, vendorComment: 'Good integration capabilities with 500+ apps' },
              { parameterId: 'd2', evalScore: 9, result: 45, vendorComment: 'Quick deployment, 4-8 weeks typical implementation' }
            ],
            subTotal: 125
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 8, result: 40, vendorComment: 'Scalable user-based licensing' },
              { parameterId: 'm2', evalScore: 8, result: 80, vendorComment: 'Growing partner ecosystem with certified partners' }
            ],
            subTotal: 120
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 8, result: 80, vendorComment: 'Strong player in Gartner Magic Quadrant' },
              { parameterId: 's2', evalScore: 9, result: 45, vendorComment: 'SOC 2 Type II, ISO 27001 certified, GDPR compliant' }
            ],
            subTotal: 125
          }
        },
        overallScore: 760,
        notes: 'Best value for marketing-focused CRM needs'
      }
    ],
    notes: 'Comprehensive CRM vendor assessment completed',
    version: 1,
    createdAt: new Date('2024-02-01'),
    updatedAt: new Date('2024-02-28'),
    createdBy: 'David Lee',
    approvedBy: 'Michael Chen',
    approvedAt: new Date('2024-03-05'),
    sharedWith: []
  },
  {
    id: 'da-5',
    name: 'Enterprise Data Warehouse Solution',
    type: 'License',
    status: 'Approved',
    templateId: 'template-1',
    vendors: [
      {
        id: 'vendor-dw-1',
        name: 'Snowflake',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 9, result: 90, vendorComment: 'Cloud-native architecture with minimal development overhead' },
              { parameterId: 'q2', evalScore: 8, result: 80, vendorComment: 'SQL-based interface with SnowSQL and worksheets' },
              { parameterId: 'q3', evalScore: 9, result: 45, vendorComment: 'Data sharing templates and marketplace available' },
              { parameterId: 'q4', evalScore: 9, result: 45, vendorComment: 'Comprehensive documentation and community support' }
            ],
            subTotal: 260
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 7, result: 70, vendorComment: 'Pay-per-use model, estimated $3000/month for medium workload' },
              { parameterId: 'c2', evalScore: 8, result: 40, vendorComment: 'Minimal setup costs, cloud deployment' }
            ],
            subTotal: 110
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 10, result: 100, vendorComment: 'Native connectors for all major data sources and BI tools' },
              { parameterId: 'd2', evalScore: 9, result: 45, vendorComment: 'Rapid deployment, 2-4 weeks to production' }
            ],
            subTotal: 145
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 9, result: 45, vendorComment: 'Consumption-based pricing model' },
              { parameterId: 'm2', evalScore: 9, result: 90, vendorComment: 'Strong partner network with major cloud providers' }
            ],
            subTotal: 135
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 9, result: 90, vendorComment: 'Leader in Gartner Magic Quadrant for Cloud Data Warehouse' },
              { parameterId: 's2', evalScore: 10, result: 50, vendorComment: 'SOC 2 Type II, ISO 27001, PCI DSS, HIPAA compliant' }
            ],
            subTotal: 140
          }
        },
        overallScore: 790,
        notes: 'Modern cloud-native solution with excellent scalability'
      },
      {
        id: 'vendor-dw-2',
        name: 'Amazon Redshift',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 8, result: 80, vendorComment: 'Mature data warehouse solution with good performance' },
              { parameterId: 'q2', evalScore: 7, result: 70, vendorComment: 'SQL interface with some AWS-specific configuration needed' },
              { parameterId: 'q3', evalScore: 7, result: 35, vendorComment: 'Limited template marketplace, custom development required' },
              { parameterId: 'q4', evalScore: 8, result: 40, vendorComment: 'AWS documentation and support available' }
            ],
            subTotal: 225
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 8, result: 80, vendorComment: 'Competitive pricing at $2500/month for similar capacity' },
              { parameterId: 'c2', evalScore: 7, result: 35, vendorComment: 'Some AWS expertise required for optimal setup' }
            ],
            subTotal: 115
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 9, result: 90, vendorComment: 'Excellent integration within AWS ecosystem' },
              { parameterId: 'd2', evalScore: 7, result: 35, vendorComment: 'Deployment timeline 4-6 weeks with configuration' }
            ],
            subTotal: 125
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 8, result: 40, vendorComment: 'Pay-as-you-go with reserved instance options' },
              { parameterId: 'm2', evalScore: 9, result: 90, vendorComment: 'AWS partner network with certified consultants' }
            ],
            subTotal: 130
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 8, result: 80, vendorComment: 'Visionary in Gartner Magic Quadrant' },
              { parameterId: 's2', evalScore: 10, result: 50, vendorComment: 'SOC 1/2/3, ISO 27001, PCI DSS certified' }
            ],
            subTotal: 130
          }
        },
        overallScore: 725,
        notes: 'Good choice for AWS-centric environments'
      }
    ],
    notes: 'Data warehouse evaluation for analytics modernization',
    version: 1,
    createdAt: new Date('2023-12-05'),
    updatedAt: new Date('2024-01-10'),
    createdBy: 'Rachel Kim',
    approvedBy: 'Emily Rodriguez',
    approvedAt: new Date('2024-01-15'),
    sharedWith: []
  },
  {
    id: 'da-6',
    name: 'Custom Mobile App Development Partner',
    type: 'Custom Development',
    status: 'Approved',
    templateId: 'template-2',
    vendors: [
      {
        id: 'vendor-mobile-1',
        name: 'ThoughtWorks',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 10, result: 150, vendorComment: 'Exceptional technical expertise with senior architects' },
              { parameterId: 'q2', evalScore: 9, result: 90, vendorComment: 'Strong adherence to clean code and SOLID principles' },
              { parameterId: 'q3', evalScore: 9, result: 90, vendorComment: 'Comprehensive test automation and CI/CD practices' }
            ],
            subTotal: 330
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 5, result: 75, vendorComment: 'Premium pricing at $150/hour blended rate' },
              { parameterId: 'c2', evalScore: 6, result: 30, vendorComment: 'Annual support at 20% of development cost' }
            ],
            subTotal: 105
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 8, result: 80, vendorComment: 'Good track record of meeting deadlines' },
              { parameterId: 'd2', evalScore: 10, result: 50, vendorComment: 'Agile champions with 2-week sprint methodology' }
            ],
            subTotal: 130
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 9, result: 90, vendorComment: 'Dedicated PM and scrum master for each project' },
              { parameterId: 'm2', evalScore: 9, result: 45, vendorComment: 'Daily standups and weekly stakeholder reviews' }
            ],
            subTotal: 135
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 10, result: 100, vendorComment: 'ISO 27001, SOC 2 Type II certified' },
              { parameterId: 's2', evalScore: 9, result: 45, vendorComment: 'OWASP security standards and penetration testing' }
            ],
            subTotal: 145
          }
        },
        overallScore: 845,
        notes: 'Top-tier consulting firm with premium pricing'
      },
      {
        id: 'vendor-mobile-2',
        name: 'Infosys',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 8, result: 120, vendorComment: 'Strong technical team with relevant certifications' },
              { parameterId: 'q2', evalScore: 8, result: 80, vendorComment: 'Good coding standards with code review processes' },
              { parameterId: 'q3', evalScore: 7, result: 70, vendorComment: 'Automated testing framework in place' }
            ],
            subTotal: 270
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 8, result: 120, vendorComment: 'Competitive at $85/hour blended rate' },
              { parameterId: 'c2', evalScore: 8, result: 40, vendorComment: 'Maintenance at 15% of development cost' }
            ],
            subTotal: 160
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 7, result: 70, vendorComment: 'Generally meets timelines with some delays' },
              { parameterId: 'd2', evalScore: 8, result: 40, vendorComment: 'Agile methodology with 3-week sprints' }
            ],
            subTotal: 110
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 7, result: 70, vendorComment: 'Dedicated PM with offshore coordination' },
              { parameterId: 'm2', evalScore: 7, result: 35, vendorComment: 'Weekly status meetings and monthly business reviews' }
            ],
            subTotal: 105
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 9, result: 90, vendorComment: 'ISO 27001, SOC 2 certified with global standards' },
              { parameterId: 's2', evalScore: 8, result: 40, vendorComment: 'Data encryption and secure development lifecycle' }
            ],
            subTotal: 130
          }
        },
        overallScore: 775,
        notes: 'Good value proposition with global delivery model'
      },
      {
        id: 'vendor-mobile-3',
        name: 'Accenture',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 9, result: 135, vendorComment: 'Highly skilled team with industry specialists' },
              { parameterId: 'q2', evalScore: 9, result: 90, vendorComment: 'Enterprise-grade code quality standards' },
              { parameterId: 'q3', evalScore: 8, result: 80, vendorComment: 'Robust QA processes with automation' }
            ],
            subTotal: 305
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 6, result: 90, vendorComment: 'Higher pricing at $120/hour blended rate' },
              { parameterId: 'c2', evalScore: 7, result: 35, vendorComment: 'Maintenance at 18% of development cost' }
            ],
            subTotal: 125
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 8, result: 80, vendorComment: 'Strong delivery track record' },
              { parameterId: 'd2', evalScore: 9, result: 45, vendorComment: 'Mature agile practices with DevOps integration' }
            ],
            subTotal: 125
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 9, result: 90, vendorComment: 'Dedicated engagement manager and delivery lead' },
              { parameterId: 'm2', evalScore: 8, result: 40, vendorComment: 'Regular governance and stakeholder communication' }
            ],
            subTotal: 130
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 10, result: 100, vendorComment: 'ISO 27001, SOC 2, CMMI Level 5 certified' },
              { parameterId: 's2', evalScore: 9, result: 45, vendorComment: 'Comprehensive security and compliance framework' }
            ],
            subTotal: 145
          }
        },
        overallScore: 830,
        notes: 'Enterprise consulting leader with strong capabilities'
      }
    ],
    notes: 'Mobile app development partner selection for customer portal',
    version: 1,
    createdAt: new Date('2024-01-20'),
    updatedAt: new Date('2024-02-25'),
    createdBy: 'James Wilson',
    approvedBy: 'David Lee',
    approvedAt: new Date('2024-03-01'),
    sharedWith: []
  },
  {
    id: 'da-7',
    name: 'HR Management SaaS Platform',
    type: 'SaaS',
    status: 'Approved',
    templateId: 'template-3',
    vendors: [
      {
        id: 'vendor-hr-1',
        name: 'Workday',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 10, result: 150, vendorComment: 'Comprehensive HR, payroll, and talent management features' },
              { parameterId: 'q2', evalScore: 8, result: 80, vendorComment: 'Modern interface but requires training for complex features' },
              { parameterId: 'q3', evalScore: 7, result: 35, vendorComment: 'Limited customization, primarily configuration-based' }
            ],
            subTotal: 265
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 5, result: 75, vendorComment: 'Premium pricing at $99/employee/month' },
              { parameterId: 'c2', evalScore: 5, result: 25, vendorComment: 'Significant implementation cost, 6-figure investment' }
            ],
            subTotal: 100
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 6, result: 60, vendorComment: 'Implementation takes 6-9 months for full deployment' },
              { parameterId: 'd2', evalScore: 8, result: 80, vendorComment: 'Good API with standard integrations available' }
            ],
            subTotal: 140
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 10, result: 100, vendorComment: 'Market leader with Fortune 500 customer base' },
              { parameterId: 'm2', evalScore: 8, result: 40, vendorComment: 'Dedicated customer success manager with SLA' }
            ],
            subTotal: 140
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 10, result: 100, vendorComment: 'SOC 1/2, ISO 27001, FedRAMP authorized' },
              { parameterId: 's2', evalScore: 10, result: 50, vendorComment: 'GDPR, CCPA compliant with global data centers' }
            ],
            subTotal: 150
          }
        },
        overallScore: 795,
        notes: 'Enterprise-grade solution, best for large organizations'
      },
      {
        id: 'vendor-hr-2',
        name: 'BambooHR',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 8, result: 120, vendorComment: 'Good core HR features, limited enterprise capabilities' },
              { parameterId: 'q2', evalScore: 10, result: 100, vendorComment: 'Outstanding user experience, very intuitive' },
              { parameterId: 'q3', evalScore: 8, result: 40, vendorComment: 'Good customization for workflows and reports' }
            ],
            subTotal: 260
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 9, result: 135, vendorComment: 'Affordable at $6-8/employee/month' },
              { parameterId: 'c2', evalScore: 10, result: 50, vendorComment: 'Low implementation cost, mostly self-service' }
            ],
            subTotal: 185
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 10, result: 100, vendorComment: 'Quick deployment, 2-4 weeks typical' },
              { parameterId: 'd2', evalScore: 7, result: 70, vendorComment: 'API available with 60+ integrations' }
            ],
            subTotal: 170
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 8, result: 80, vendorComment: 'Strong reputation in SMB market' },
              { parameterId: 'm2', evalScore: 9, result: 45, vendorComment: 'Excellent customer support with quick response times' }
            ],
            subTotal: 125
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 8, result: 80, vendorComment: 'SOC 2 Type II certified' },
              { parameterId: 's2', evalScore: 9, result: 45, vendorComment: 'GDPR compliant with data privacy controls' }
            ],
            subTotal: 125
          }
        },
        overallScore: 865,
        notes: 'Best choice for SMB with excellent user experience'
      }
    ],
    notes: 'HR platform evaluation for employee management',
    version: 1,
    createdAt: new Date('2023-11-15'),
    updatedAt: new Date('2023-12-20'),
    createdBy: 'Lisa Anderson',
    approvedBy: 'James Wilson',
    approvedAt: new Date('2023-12-22'),
    sharedWith: []
  },
  {
    id: 'da-8',
    name: 'Cybersecurity Platform Selection',
    type: 'License',
    status: 'Approved',
    templateId: 'template-1',
    vendors: [
      {
        id: 'vendor-sec-1',
        name: 'CrowdStrike',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 9, result: 90, vendorComment: 'Cloud-native architecture with AI-powered threat detection' },
              { parameterId: 'q2', evalScore: 9, result: 90, vendorComment: 'Lightweight agent with centralized cloud console' },
              { parameterId: 'q3', evalScore: 8, result: 40, vendorComment: 'Pre-built detection templates with custom rule creation' },
              { parameterId: 'q4', evalScore: 10, result: 50, vendorComment: '24/7 threat intelligence and research team support' }
            ],
            subTotal: 270
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 7, result: 70, vendorComment: 'Annual license $99/endpoint for full suite' },
              { parameterId: 'c2', evalScore: 8, result: 40, vendorComment: 'Professional services for deployment included' }
            ],
            subTotal: 110
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 9, result: 90, vendorComment: 'Integration with SIEM and SOAR platforms via API' },
              { parameterId: 'd2', evalScore: 9, result: 45, vendorComment: 'Rapid deployment, 1-2 weeks for 1000+ endpoints' }
            ],
            subTotal: 135
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 9, result: 45, vendorComment: 'Per-endpoint subscription model with flexible tiers' },
              { parameterId: 'm2', evalScore: 10, result: 100, vendorComment: 'Large partner network with MSSPs and resellers' }
            ],
            subTotal: 145
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 10, result: 100, vendorComment: 'Leader in Gartner Magic Quadrant for Endpoint Protection' },
              { parameterId: 's2', evalScore: 10, result: 50, vendorComment: 'SOC 2 Type II, ISO 27001, FedRAMP High authorized' }
            ],
            subTotal: 150
          }
        },
        overallScore: 810,
        notes: 'Industry leader with advanced threat protection'
      },
      {
        id: 'vendor-sec-2',
        name: 'Palo Alto Networks',
        scores: {
          quality: {
            evaluations: [
              { parameterId: 'q1', evalScore: 9, result: 90, vendorComment: 'Comprehensive security platform with firewall integration' },
              { parameterId: 'q2', evalScore: 8, result: 80, vendorComment: 'Unified management console for network and endpoint' },
              { parameterId: 'q3', evalScore: 9, result: 45, vendorComment: 'Extensive security policy templates' },
              { parameterId: 'q4', evalScore: 9, result: 45, vendorComment: 'Unit 42 threat research team and extensive documentation' }
            ],
            subTotal: 260
          },
          cost: {
            evaluations: [
              { parameterId: 'c1', evalScore: 6, result: 60, vendorComment: 'Premium pricing at $120/endpoint annually' },
              { parameterId: 'c2', evalScore: 7, result: 35, vendorComment: 'Implementation costs moderate with partner support' }
            ],
            subTotal: 95
          },
          delivery: {
            evaluations: [
              { parameterId: 'd1', evalScore: 10, result: 100, vendorComment: 'Excellent integration with existing Palo Alto infrastructure' },
              { parameterId: 'd2', evalScore: 8, result: 40, vendorComment: 'Deployment takes 2-3 weeks with network integration' }
            ],
            subTotal: 140
          },
          management: {
            evaluations: [
              { parameterId: 'm1', evalScore: 8, result: 40, vendorComment: 'Subscription-based licensing with multiple tiers' },
              { parameterId: 'm2', evalScore: 9, result: 90, vendorComment: 'Strong global partner ecosystem' }
            ],
            subTotal: 130
          },
          safety: {
            evaluations: [
              { parameterId: 's1', evalScore: 10, result: 100, vendorComment: 'Leader in multiple Gartner Magic Quadrants' },
              { parameterId: 's2', evalScore: 10, result: 50, vendorComment: 'ISO 27001, SOC 2, Common Criteria certified' }
            ],
            subTotal: 150
          }
        },
        overallScore: 775,
        notes: 'Strong choice for unified security platform'
      }
    ],
    notes: 'Endpoint security and threat protection platform evaluation',
    version: 1,
    createdAt: new Date('2024-02-10'),
    updatedAt: new Date('2024-03-15'),
    createdBy: 'Alex Thompson',
    approvedBy: 'Rachel Kim',
    approvedAt: new Date('2024-03-18'),
    sharedWith: []
  }
];