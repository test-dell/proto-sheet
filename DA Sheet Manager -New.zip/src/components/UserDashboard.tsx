import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  FileText, 
  Plus, 
  Download, 
  Eye,
  Trash2,
  ArrowLeft,
  Search,
  Users
} from 'lucide-react';
import { DASheet, Template } from '../types/da-types';
import { toast } from 'sonner@2.0.3';
import { DAPreview } from './DAPreview';

interface UserDashboardProps {
  daSheets: DASheet[];
  templates: Template[];
  onCreateNew: () => void;
  onDeleteSheet: (sheetId: string) => void;
  onBack: () => void;
  isAdmin?: boolean;
}

export function UserDashboard({ 
  daSheets, 
  templates,
  onCreateNew, 
  onDeleteSheet,
  onBack,
  isAdmin = true // Default to admin for now
}: UserDashboardProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [selectedSheet, setSelectedSheet] = useState<DASheet | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);

  // Filter only finalized (Approved) DA sheets
  const finalizedSheets = daSheets.filter(sheet => sheet.status === 'Approved');

  // Apply search and filters
  const filteredSheets = finalizedSheets.filter(sheet => {
    const matchesSearch = sheet.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          sheet.createdBy.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || sheet.type === filterType;
    return matchesSearch && matchesType;
  });

  const handleDownload = (sheet: DASheet) => {
    toast.success(`Downloading "${sheet.name}"...`);
    // Mock PDF export
    setTimeout(() => {
      toast.success('PDF downloaded successfully');
    }, 1000);
  };

  const handleDelete = (sheet: DASheet) => {
    if (window.confirm(`Are you sure you want to delete "${sheet.name}"? This action cannot be undone.`)) {
      onDeleteSheet(sheet.id);
      toast.success('DA Sheet deleted successfully');
    }
  };

  const handlePreview = (sheet: DASheet) => {
    const template = templates.find(t => t.id === sheet.templateId);
    setSelectedSheet(sheet);
    setSelectedTemplate(template || null);
    setIsPreviewOpen(true);
  };

  const handleExportPDF = () => {
    setIsPreviewOpen(false);
    toast.success('Exporting DA Sheet as PDF...');
    setTimeout(() => {
      toast.success('PDF downloaded successfully');
    }, 1000);
  };

  const handleTemplatePreview = (template: Template) => {
    setSelectedTemplate(template);
    setIsPreviewOpen(true);
  };

  return (
    <div>
      {/* Header */}
      <header className="bg-gradient-to-r from-indigo-600 to-purple-600 border-b shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                onClick={onBack}
                className="text-white hover:bg-white/20"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <div className="border-l border-white/30 pl-4">
                <div className="flex items-center gap-4">
                  <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                    <Users className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h1 className="text-4xl text-white" style={{ fontFamily: 'system-ui, -apple-system, sans-serif', fontWeight: '700' }}>
                      User Dashboard
                    </h1>
                    <p className="text-indigo-100 mt-1">View all finalized DA sheets</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filter Section */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search by DA sheet name or creator..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="License">License</SelectItem>
                  <SelectItem value="Custom Development">Custom Development</SelectItem>
                  <SelectItem value="SaaS">SaaS</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Finalized DA Sheets List */}
        <Card>
          <CardHeader>
            <CardTitle>Finalized DA Sheets</CardTitle>
            <CardDescription>
              View and download approved decision analysis sheets
            </CardDescription>
          </CardHeader>
          <CardContent>
            {filteredSheets.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-gray-900 mb-2">
                  {searchQuery || filterType !== 'all' 
                    ? 'No matching DA Sheets found' 
                    : 'No finalized DA Sheets yet'}
                </h3>
                <p className="text-gray-600 mb-4">
                  {searchQuery || filterType !== 'all'
                    ? 'Try adjusting your search or filter criteria'
                    : 'Finalized DA sheets will appear here once approved'}
                </p>
                {!searchQuery && filterType === 'all' && (
                  <Button onClick={onCreateNew} className="bg-indigo-600 hover:bg-indigo-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Create New DA Sheet
                  </Button>
                )}
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>DA Sheet Name</TableHead>
                      <TableHead>Version</TableHead>
                      <TableHead>Created By</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredSheets.map((sheet) => (
                      <TableRow key={sheet.id}>
                        <TableCell>
                          <p className="text-gray-900">{sheet.name}</p>
                        </TableCell>
                        <TableCell>v{sheet.version}</TableCell>
                        <TableCell>{sheet.createdBy}</TableCell>
                        <TableCell>
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handlePreview(sheet)}
                              className="hover:bg-indigo-50 hover:text-indigo-600"
                              title="View DA Sheet"
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDownload(sheet)}
                              className="hover:bg-green-50 hover:text-green-600"
                              title="Download PDF"
                            >
                              <Download className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      {/* DA Sheet Preview Modal */}
      {isPreviewOpen && (
        <DAPreview
          sheet={selectedSheet}
          template={selectedTemplate}
          onClose={() => setIsPreviewOpen(false)}
          onExportPDF={handleExportPDF}
        />
      )}
    </div>
  );
}