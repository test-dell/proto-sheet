import { X } from 'lucide-react';
import { Button } from './ui/button';

interface FilePreviewModalProps {
  name: string;
  url: string;
  type: string;
  onClose: () => void;
}

export function FilePreviewModal({ name, url, type, onClose }: FilePreviewModalProps) {
  const isPDF = type === 'pdf' || name.toLowerCase().endsWith('.pdf');
  const isImage = type === 'png' || type === 'jpg' || type === 'jpeg' || /\.(jpg|jpeg|png|gif|bmp|webp)$/i.test(name);
  const isDoc = /\.(doc|docx)$/i.test(name);
  const isExcel = /\.(xls|xlsx)$/i.test(name);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-5xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex-1 min-w-0 pr-4">
            <h2 className="text-xl font-semibold text-gray-900 truncate">{name}</h2>
            <p className="text-sm text-gray-600 mt-1">Document Preview</p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="flex-shrink-0"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6 bg-gray-50">
          {isPDF && (
            <div className="w-full h-full min-h-[600px] bg-white rounded-lg shadow-sm">
              <iframe
                src={url}
                className="w-full h-full min-h-[600px] rounded-lg"
                title={name}
              />
            </div>
          )}
          
          {isImage && (
            <div className="flex items-center justify-center h-full min-h-[400px]">
              <img
                src={url}
                alt={name}
                className="max-w-full max-h-full object-contain rounded-lg shadow-lg"
              />
            </div>
          )}
          
          {(isDoc || isExcel) && (
            <div className="flex flex-col items-center justify-center h-full min-h-[400px] text-center">
              <div className="bg-white p-8 rounded-lg shadow-sm max-w-md">
                <div className="mb-4">
                  <svg className="w-20 h-20 mx-auto text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {isDoc ? 'Word Document' : 'Excel Spreadsheet'}
                </h3>
                <p className="text-gray-600 mb-4">
                  Preview is not available for this file type.
                </p>
                <p className="text-sm text-gray-500 mb-4">
                  File: {name}
                </p>
                <Button
                  onClick={() => window.open(url, '_blank')}
                  className="bg-indigo-600 hover:bg-indigo-700"
                >
                  Download to View
                </Button>
              </div>
            </div>
          )}

          {!isPDF && !isImage && !isDoc && !isExcel && (
            <div className="flex flex-col items-center justify-center h-full min-h-[400px] text-center">
              <div className="bg-white p-8 rounded-lg shadow-sm max-w-md">
                <div className="mb-4">
                  <svg className="w-20 h-20 mx-auto text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">File Uploaded</h3>
                <p className="text-gray-600 mb-4">
                  Preview is not available for this file type.
                </p>
                <p className="text-sm text-gray-500 mb-4">
                  File: {name}
                </p>
                <Button
                  onClick={() => window.open(url, '_blank')}
                  className="bg-indigo-600 hover:bg-indigo-700"
                >
                  Download File
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 p-4 border-t bg-gray-50">
          <Button
            variant="outline"
            onClick={onClose}
          >
            Close
          </Button>
          <Button
            onClick={() => window.open(url, '_blank')}
            className="bg-indigo-600 hover:bg-indigo-700"
          >
            Download
          </Button>
        </div>
      </div>
    </div>
  );
}