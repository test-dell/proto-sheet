
  # DA Sheet Manager - Teja

  This is a code bundle for DA Sheet Manager - Teja. The original project is available at https://www.figma.com/design/haE2P0SJmS8IdTBgHBPpBz/DA-Sheet-Manager---Teja.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  