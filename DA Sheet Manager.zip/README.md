
  # DA Sheet Manager - other

  This is a code bundle for DA Sheet Manager - other. The original project is available at https://www.figma.com/design/I68vSjdeO7knu1XiouDVJ6/DA-Sheet-Manager---other.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  